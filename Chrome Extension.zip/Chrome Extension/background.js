console.log('Background script loaded');

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Message received in background:', request);
  
  if (request.action === 'generateCoverLetter') {
    handleCoverLetterGeneration(request.data)
      .then(result => {
        console.log('Generation successful:', result);
        sendResponse({ success: true, data: result });
      })
      .catch(error => {
        console.error('Generation failed:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }
});

async function handleCoverLetterGeneration(data) {
  console.log('Starting cover letter generation...');
  const { resume, jobPosting, hfToken } = data;
  
  const MODEL_ID = 'google/flan-t5-large';
  console.log('Using model:', MODEL_ID);
  
  console.log('Building prompt...');
  const prompt = buildPrompt(resume, jobPosting);
  console.log('Prompt length:', prompt.length, 'characters');
  console.log('Prompt preview:', prompt.substring(0, 200) + '...');
  
  console.log('Calling Hugging Face API...');
  const coverLetter = await callHuggingFace(prompt, hfToken, MODEL_ID);
  console.log('Cover letter generated, length:', coverLetter.length, 'characters');
  
  console.log('Generating download...');
  await generatePDF(coverLetter, jobPosting);
  console.log('Download initiated');
  
  return { coverLetter };
}

function buildPrompt(resume, jobPosting) {
  return `Write a professional cover letter for this job application.

Job Title: ${jobPosting.title}
Company: ${jobPosting.company}
Location: ${jobPosting.location}

Job Description:
${jobPosting.description}

Candidate's Resume:
${resume}

Generate a compelling cover letter that highlights relevant experience and explains why the candidate is a great fit for this position.`;
}

async function callHuggingFace(prompt, token, modelId) {
  const API_URL = `https://api-inference.huggingface.co/models/${modelId}`;
  console.log('API URL:', API_URL);
  
  try {
    console.log('Sending request to Hugging Face...');
    const requestBody = {
      inputs: prompt,
      parameters: {
        max_length: 1024,
        temperature: 0.7,
        top_p: 0.9,
        do_sample: true,
        repetition_penalty: 1.2
      },
      options: {
        wait_for_model: true,
        use_cache: false
      }
    };
    console.log('Request parameters:', requestBody.parameters);
    
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestBody)
    });
    
    console.log('Response status:', response.status, response.statusText);
    
    if (!response.ok) {
      const error = await response.text();
      console.error('API error response:', error);
      throw new Error(`HuggingFace API error (${response.status}): ${error}`);
    }
    
    const result = await response.json();
    console.log('API response:', result);
    
    let generatedText = '';
    
    if (Array.isArray(result)) {
      if (result[0]?.generated_text) {
        generatedText = result[0].generated_text;
      } else if (typeof result[0] === 'string') {
        generatedText = result[0];
      }
    } else if (result.generated_text) {
      generatedText = result.generated_text;
    } else if (typeof result === 'string') {
      generatedText = result;
    } else {
      console.error('Unexpected response format:', result);
      throw new Error('Unexpected response format: ' + JSON.stringify(result));
    }
    
    console.log('Extracted text length:', generatedText.length);
    console.log('Generated text preview:', generatedText.substring(0, 200) + '...');
    
    return generatedText.trim();
    
  } catch (error) {
    console.error('Error calling Hugging Face:', error);
    throw error;
  }
}

async function generatePDF(coverLetterText, jobPosting) {
  console.log('Creating download file...');
  const content = `COVER LETTER
${jobPosting.company ? `For: ${jobPosting.company}` : ''}
${jobPosting.title ? `Position: ${jobPosting.title}` : ''}

${coverLetterText}
`;
  
  const blob = new Blob([content], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  
  const filename = `CoverLetter_${jobPosting.company || 'Job'}_${Date.now()}.txt`;
  console.log('Download filename:', filename);
  
  await chrome.downloads.download({
    url: url,
    filename: filename,
    saveAs: true
  });
  
  console.log('Download started');
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}